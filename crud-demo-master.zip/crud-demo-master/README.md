# Crud Demo 

This is the source code for ["Building a CRUD app with Node, Express, and MongoDB"](https://zellwk.com/blog/crud-express-mongodb). 
